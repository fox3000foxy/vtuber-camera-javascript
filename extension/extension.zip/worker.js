
new VirtualCameraManager.default();